comment = 'Cody Gentry, 07/06/2019, code by Automate the Boring Stuff with Python'
h = 'Hello World!'

print(comment)
print(h)
